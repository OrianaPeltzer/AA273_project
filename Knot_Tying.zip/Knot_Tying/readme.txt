kinematic variables
1-3    (3) : Master left tooltip xyz                    
4-12   (9) : Master left tooltip R    
13-15  (3) : Master left tooltip trans_vel x', y', z'   
16-18  (3) : Master left tooltip rot_vel                
19     (1) : Master left gripper angle                  
20-38  (19): Master right
39-41  (3) : Slave left tooltip xyz
42-50  (9) : Slave left tooltip R
51-53  (3) : Slave left tooltip trans_vel x', y', z'   
54-56  (3) : Slave left tooltip rot_vel
57     (1) : Slave left gripper angle                   
58-76  (19): Slave right

meta_file
1:  filename
2:  skill-level self-proclaimed
    E-expert (>100hrs), I-intermediate (10-100hrs), N-novice (<10hrs)
3:  skill-level GRS
4-9(6): score of each element of modified global rating score, in the order of
	Respect for tissue
	Suture/needle handling
	Time and motion
	Flow of operation
	Overall performance
	Quality of final product
 
transcriptions
1: start frame 
2: end frame
3: Gesture ID 

video
capture1: left
capture2: right

Gesture used in each task:
Suturing:  1, 2, 3, 4, 5, 6, 8, 9, 10, 11
Knot_Tying: 1 , 11 , 12 , 13 , 14 , 15
NeedlePassing: 1, 2, 3, 4, 5, 6, 8, 11
